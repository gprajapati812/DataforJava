package com.cg.mobile.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.dto.MobileDetails;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileApplicationException;

public interface IMobileService {

	public int addPurchaseDetails(PurchaseDetails p) throws MobileApplicationException;
	//int is return type here as it returns rows and cols as integer
	//we are getting ui details from purchase detail
	
	public boolean validateName(String name);
	public boolean validateEmail(String email);
	public boolean validatePhoneNo(String phone);
	public boolean validateMobId(String mobid) throws IOException, SQLException;
	public ArrayList<MobileDetails> retrieveDetails();	//POJO class method

}
