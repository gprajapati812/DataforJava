package com.cg.mobile.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.dto.MobileDetails;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileApplicationException;

public interface IMobileDAO {
	public int addPurchaseDetails(PurchaseDetails p) throws MobileApplicationException;

	public int checkMobileIdInTable(String mobid) throws IOException, SQLException;

	public ArrayList<MobileDetails> retrieveDetails();

	
}
