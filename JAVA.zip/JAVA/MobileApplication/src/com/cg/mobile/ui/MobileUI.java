package com.cg.mobile.ui;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobile.dto.MobileDetails;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileApplicationException;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileUI {
	
	static Scanner sc = new Scanner(System.in);		//scanner is static becoz the methods below are also static
	static PurchaseDetails details = null;		//obj created for purchase details class
	static IMobileService service= new MobileServiceImpl();
	public static void main(String[] args) throws MobileApplicationException, IOException, SQLException {
		
		
		System.out.println("Mobile Application");
		System.out.println("_______________________");
		while(true)
		{
			System.out.println("1.Enter Purchase Details");
			System.out.println("2.Get the Mobile Details");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 1 : addPurchasedetails();
						break;
			case 2 : getMobileDetails();
						break;
			case 3 : System.exit(0);
			}
		}
		
	}

	private static void getMobileDetails() {
		
		ArrayList <MobileDetails> list =null;
		list = service.retrieveDetails();
		for(MobileDetails m:list)
		{
			System.out.println(m.getMobileid());
			System.out.println(m.getName());
			System.out.println(m.getPrice());
			System.out.println(m.getQuantity());
		}
	}

	private static void addPurchasedetails() throws MobileApplicationException, IOException, SQLException {
		// TODO Auto-generated method stub
		try{
		System.out.println("Enter Customer Name");
		String sname = sc.next();
		if(service.validateName(sname))
		{
			System.out.println("Enter Mail Id");
			String smail = sc.next();
		
			if(service.validateEmail(smail))
			{
				System.out.println("Enter Phone number");
				long sphone = sc.nextLong();
				String num=String.valueOf(sphone);
		
					if(service.validatePhoneNo(num))
					{
						System.out.println("Enter Mobile id");
						int smobid = sc.nextInt();
						String mobid=String.valueOf(smobid);
		
							if(service.validateMobId(mobid))
							{
								//constructor should b used to provide above obtained data to purchasedetails class.
								//obj 'details' is used call constructor
		
								details = new PurchaseDetails(sname,smail,sphone,smobid); //constructor is called
								//purchaseid and localdate was removed from constructor PurchaseDetails in PurchaseDetails class
								//as we taking only 4 values from user
		
								//now we need to pass this details to service layer.we create obj 'service' for this
								service = new MobileServiceImpl();
		
								int no_of_rows = service.addPurchaseDetails(details);
								System.out.println(no_of_rows+" rows inserted");
									if(no_of_rows==1)
									{
										System.out.println("Value added in database");
									}
									else
									{
										System.out.println("value not added");
									}
							}
							
					}
			}
		}
	}
	catch(MobileApplicationException e)
	{
		//exception display(type 1):User defined exception
		throw new MobileApplicationException("The Exception Occured!!");
		//exception display(type 2)
		//System.out.println("Exception occured!! Error is:"+e.getMessage());
	}
	}
}
