package com.cg.mobile.test;

import static org.junit.Assert.*;

import org.junit.*;

import com.cg.mobile.dao.IMobileDAO;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileApplicationException;

public class TestMobileApp {
	static IMobileDAO dao=null;
	static PurchaseDetails bean=null;
	
	@BeforeClass
	public static void initialize() {
		dao=new MobileDaoImpl();
		bean=new PurchaseDetails();
		
	}
	@Test
	public void testData()
	{
		bean.setCname("Aditi");
		bean.setMailid("abc@gmail.com");
		bean.setMobileId(1001);
		bean.setPhoneno(123);
		bean.setPurchaseid(10);
	}
	
	@Test
	public void testAddDetails() throws MobileApplicationException
	{
		assertNotNull(dao.addPurchaseDetails(bean));
	}
	@Test
	public void getDetails()
	{
		assertNotNull(dao.retrieveDetails());
	}

}
