package com.cg.mobile.exception;

public class MobileApplicationException extends Exception{

	public MobileApplicationException(String msg) {

		super(msg);
	}

	
}
