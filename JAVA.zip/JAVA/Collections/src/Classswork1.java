import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

//Check output for what all operations were done
public class Classswork1 {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> a1 = new ArrayList<Integer>();
		a1.add(5);
		a1.add(3);
		a1.add(2);
		a1.add(6);
		a1.add(9);
		
		ArrayList<Integer> a2 = new ArrayList<Integer>();
		a2.add(1);
		a2.add(4);
		a2.add(7);
		a2.add(8);
		a2.add(6);
		
		//merging 2 arrays
		a1.addAll(a2);
		System.out.println("Merged array a1");
		System.out.println(a1);
		
		System.out.println("Sorted array a1");
		Collections.sort(a1);
		System.out.println(a1);
		
		ArrayList<Integer> a3 = new ArrayList<Integer>();
		
		a3.add(a1.get(2));
		a3.add(a1.get(6));
		a3.add(a1.get(8));
		System.out.println("Elements of a1 from 2nd, 6th and 8th position");
		System.out.println(a3);
		
		System.out.println("iterate for a1");
		for(Integer a:a1)
		{
			System.out.println(a);
		}
		
		System.out.println("iterate for a2");
		for(Integer a:a2)
		{
			System.out.println(a);
		}
		
		System.out.println("iterate for a3");
		for(Integer a:a3)
		{
			System.out.println(a);
		}
		
	}

}
