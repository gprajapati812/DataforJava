import java.util.*;




public class Array_List {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> a1 = new ArrayList<Integer>();
		a1.add(50);
		a1.add(20);
		a1.add(14);
		a1.add(30);
		Collections.sort(a1);		//sorts elements in forward direction
		//System.out.println(a1);
		
		ArrayList<Integer> a2 = new ArrayList<Integer>();
		System.out.println("Enter array2 elements");
		a2.add(sc.nextInt());
		a2.add(sc.nextInt());
		a2.add(sc.nextInt());
		a2.add(sc.nextInt());
		Collections.sort(a2);
		//System.out.println(a2);
		
		//a1.addAll(a2);			//adds both array elements.keeps duplicates
		//System.out.println(a1);
		
		//a1.retainAll(a2);			//Outputs the common between two
		//System.out.println(a1);
		
		//a1.removeAll(a2);			//removes duplicate elements and prints only a1 elements
		//System.out.println(a1);
		
		//int size =a1.size();		//prints no. of elements in a1
		//System.out.println(size);
		
		//Iteration using for each loop
		/*for(Integer a:a1)
		{
			System.out.println(a);
		}*/
		
		//Using iterator loop
		Iterator itr = a1.iterator();
		while(itr.hasNext())
		{
			Integer a = (Integer) itr.next();
			System.out.println(a);
		
		
		
		}
	}

}
