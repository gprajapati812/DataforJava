import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;


public class MapExample {
	
	public static void main(String[] args) {
		
		//If you use LinkedHashMAp you will get insertion ordered output
		TreeMap<Integer,String> hm=new TreeMap<Integer,String>();
		hm.put(104, "Ram");
		hm.put(102, "Ram");
		hm.put(305, "Sundar");
		hm.put(103, "Rohit");
		hm.put(201, "Meet");
		//System.out.println(hm);
		
		//iteration using for each
		System.out.println("iteration using for each\n");
		for(Map.Entry out:hm.entrySet())
		{
			Integer key=(Integer) out.getKey();
			String value =(String) out.getValue();
			System.out.println(key);
			System.out.println(value);
			
		}
		
		//iteration using iterator
		System.out.println("iteration using iterator\n");
		Iterator<Integer> itr=hm.keySet().iterator();
		while(itr.hasNext())
		{
			Integer k=itr.next();
			String v=hm.get(k);
			System.out.println(k);
			System.out.println(v);
		}
		
		
	}

}
