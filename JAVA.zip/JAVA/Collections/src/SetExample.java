import java.util.*;


public class SetExample {

	public static void main(String[] args) {
		
		//Random order sort and duplicates not allowed 
		
		HashSet<String> hs = new HashSet<String>();
		
		
		hs.add("one");
		hs.add("four");
		hs.add("three");
		hs.add("four");
		System.out.println(hs);
		
		//order is maintained
		LinkedHashSet<String> lhs = new LinkedHashSet<String>();
		
		
		lhs.add("one");
		lhs.add("four");
		lhs.add("three");
		lhs.add("four");
		System.out.println(lhs);
		
		
		
		
	}
}
