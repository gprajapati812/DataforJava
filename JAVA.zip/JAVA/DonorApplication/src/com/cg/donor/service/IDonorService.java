package com.cg.donor.service;

import com.cg.donor.dto.DonorDetails;

public interface IDonorService {

	public int addDonorDetails(DonorDetails details);
}
