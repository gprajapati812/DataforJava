package com.cg.donor.service;

import com.cg.donor.dao.DonorDaoImpl;
import com.cg.donor.dao.IDonorDao;
import com.cg.donor.dto.DonorDetails;


public class IDonorServiceImpl implements IDonorService {

	IDonorDao dao = new DonorDaoImpl();
	
	public int addDonorDetails(DonorDetails p) {
		IDonorDao dao = new DonorDaoImpl();
		return dao.addDonorDetails(p);
		
	}
}
