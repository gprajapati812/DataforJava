package com.cg.donor.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.donor.dbutil.DBDonorUtil;
import com.cg.donor.dto.DonorDetails;


public class DonorDaoImpl implements IDonorDao{

	Connection conn=null;
	
	public int addDonorDetails(DonorDetails p)
	{
		int result = 0;
		try {
			conn=DBDonorUtil.getConnection();
			
			String insertQuery="insert into donordetails values(donor_seq_id.nextval,?,?,?,?,SYSDATE)";
			PreparedStatement ps=conn.prepareStatement(insertQuery);
			ps.setString(1, p.getDonorName());
			ps.setString(2, p.getPhoneNo());
			ps.setString(3, p.getAddress());
			ps.setInt(4,p.getDonationAmt());
			result = ps.executeUpdate();
		} 
		
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
