package com.cg.donor.dao;

import com.cg.donor.dto.DonorDetails;

public interface IDonorDao {

	public int addDonorDetails(DonorDetails p);

	
}
