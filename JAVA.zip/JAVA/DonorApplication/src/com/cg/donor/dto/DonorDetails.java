package com.cg.donor.dto;

import java.time.LocalDate;

public class DonorDetails {

	@Override
	public String toString() {
		return "DonorDetails [donorName=" + donorName + ", phoneNo=" + phoneNo
				+ ", address=" + address + ", donationAmt=" + donationAmt + "]";
	}


	//private String donorId;
	private String donorName;
	private String phoneNo;
	private String address;
	private int donationAmt;
	//private LocalDate donateDate;
	
	/*public String getDonorId() {
		return donorId;
	}
	public void setDonorId(String donorId) {
		this.donorId = donorId;
	}*/
	public String getDonorName() {
		return donorName;
	}
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getDonationAmt() {
		return donationAmt;
	}
	public void setDonationAmt(int donationAmt) {
		this.donationAmt = donationAmt;
	}
	/*public LocalDate getDonateDate() {
		return donateDate;
	}
	public void setDonateDate(LocalDate donateDate) {
		this.donateDate = donateDate;
	}*/
	public DonorDetails( String donorName, String phoneNo,
			String address, int donationAmt) {
		super();
		//this.donorId = donorId;
		this.donorName = donorName;
		this.phoneNo = phoneNo;
		this.address = address;
		this.donationAmt = donationAmt;
		//this.donateDate = donateDate;
	}
	
	
	public DonorDetails()
	{
		
	}
	
}
