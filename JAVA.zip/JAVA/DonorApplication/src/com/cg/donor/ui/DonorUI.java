package com.cg.donor.ui;

import java.util.Scanner;

import com.cg.donor.dto.DonorDetails;
import com.cg.donor.service.IDonorService;
import com.cg.donor.service.IDonorServiceImpl;




public class DonorUI {

	static Scanner sc = new Scanner(System.in);
	static DonorDetails details = null;		
	static IDonorService service= new IDonorServiceImpl();
	
	public static void main(String[] args) {
		
		System.out.println("Donor Application");
		System.out.println("_______________________");
		while(true)
		{
			System.out.println("1.Enter Donor Details");
			System.out.println("2.Get Donor Details");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 1 : addDonordetails();
						break;
			case 2 : //getMobileDetails();
						break;
			case 3 : System.exit(0);
			}
		}
		
	}
	
	
	private static void addDonordetails()
	{
		
			System.out.println("Enter Donor Name");
			String dname = sc.next();
			
				System.out.println("Enter Phone no");
				String dphone = sc.next();
			
				
					System.out.println("Enter Address");
					String daddress = sc.next();
			
						
							System.out.println("Enter donor amount");
							int ddonoramt = sc.nextInt();
						
									details = new DonorDetails(dname,dphone,daddress,ddonoramt); 

									service = new IDonorServiceImpl();

									int no_of_rows = service.addDonorDetails(details);
									System.out.println(no_of_rows+" rows inserted");
										if(no_of_rows==1)
										{
											System.out.println("Value added in database");
										}
										else
										{
											System.out.println("value not added");
										}

								}
}
