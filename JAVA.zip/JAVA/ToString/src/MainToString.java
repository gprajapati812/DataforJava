
public class MainToString {

	public static void main(String[] args) {
		
	Student s1 = new Student(111,"Adi");		//class name should be same as that of class from where you are getting values
	Student s2 = new Student(112,"Pachi");
	
	System.out.println(s1);
	System.out.println(s2);
	
	
	
	Student s3 = new Student(11,"A");		//class name should be same as that of class from where you are getting values
	Student s4 = new Student(11,"A");
	
	System.out.println(s3.hashCode());
	System.out.println(s4.hashCode());
	
	boolean b= s3.equals(s4);
	System.out.println(b);
	
	}

	
}
