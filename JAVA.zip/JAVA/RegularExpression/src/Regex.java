import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Regex {
	
	public static void main(String[] args) {
		
		//Using pattern class
		String s = "Aditi";
		String reg = "[A-Z]{1}[a-z]{4}";
		boolean b = Pattern.matches(reg, s);
		
		String phone="2652136010";
		String regx="[789]{1}[0-9]*";
		boolean a = Pattern.matches(regx, phone);
		
		//System.out.println(b);
		
		//Using Matcher class 
		Pattern p = Pattern.compile("[0-9]{1}[a-zA-Z]{3,}");
		Matcher m = p.matcher("1abcAB");
		boolean c = m.matches();
		System.out.println(c);
	}

}
