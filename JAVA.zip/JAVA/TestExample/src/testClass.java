import static org.junit.Assert.*;

import org.junit.Test;


public class testClass {

	@Test
	public void test() {
		Calculator cl=new Calculator();
		int result=cl.add(2,4);
		assertEquals(6,result);
		
	}

}
