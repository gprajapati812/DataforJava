
enum directions
{
	SOUTH,NORTH,EAST,WEST;
}


public class EnumExample {
		public static void main(String[] args) {
			
			for(directions s:directions.values())	//Advanced loop. Used to call all values of enum
			System.out.println(s);
			
			System.out.println("\n"+directions.SOUTH); //Used to print single element of the enum
		}
	
}
