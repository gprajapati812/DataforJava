import java.util.Scanner;


enum gender
	{
		FEMALE,MALE;
		
	}


public class EnumGender {
	

	public static void main(String[] args) {
		
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter your first name:");
	String name=sc.next();
	System.out.println("Enter your last name:");
	String lname=sc.next();
	System.out.println("Enter gender");
	char gend =sc.next().charAt(0);
	
	System.out.println("Person Details:\n_____________\n\nFirst Name: "+name+"\nLast Name: "+lname);
	
	if(gend=='m' || gend=='M')
		System.out.println("Gender is :"+gender.MALE);
	
	else if(gend=='f' || gend=='F')
		System.out.println("Gender is:"+gender.FEMALE);
	else
		System.out.println("Invalid Input");
	}
}
