import java.util.Scanner;


public class PersonMain {
	
	public static void main(String[] args) {
		Person p = new Person();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("FirstName:");
		String firstName=sc.next();
		p.setFirstName(firstName); // you type p. and it will show drop down to select set()
		
		System.out.println("LastName:");
		String lastName=sc.next();
		p.setLastName(lastName);
		
		System.out.println("Gender");
		char gender=sc.next().charAt(0);
		p.setGender(gender);
		
		System.out.println("Person Details\n______________________\nFirst Name: "+firstName+"\nLast Name: "+lastName+"\nGender: "+gender);
		
	}
}
