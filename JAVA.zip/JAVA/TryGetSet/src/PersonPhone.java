
class PersonPhone { //A class which has private members...we use getter setter to access it


	
	private String firstName;
	private String lastName;
	private char gender;
	private long phoneno;
	PersonPhone()
	{
	}
	
		public PersonPhone(String firstName, String lastName, char gender, long phoneno) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneno = phoneno;
	}



		public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
		
}
