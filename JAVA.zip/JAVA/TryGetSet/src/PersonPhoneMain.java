import java.util.Scanner;


public class PersonPhoneMain {
	
	public static void main(String[] args) {
		
		PersonPhone v = new PersonPhone();
		PersonPhoneMain p = new PersonPhoneMain();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("FirstName:");
		String firstName=sc.next();
		v.setFirstName(firstName);
		
		System.out.println("LastName:");
		String lastName=sc.next();
		v.setLastName(lastName);
		
		System.out.println("Gender");
		char gender=sc.next().charAt(0);
		v.setGender(gender);
		
		System.out.println("Phoneno");
		long phoneno=sc.nextLong();
		v.setPhoneno(phoneno);
		
		p.printDetails(v);
		
	
	}
	
	void printDetails(PersonPhone v)
	{
		System.out.println("Person Details\n______________________");
		System.out.println("\nFirst Name: "+v.getFirstName());
		System.out.println("\nLast Name: "+v.getLastName());
		System.out.println("\nGender: "+v.getGender());
		System.out.println("\nPhone no: "+v.getPhoneno());
	}

}
