
public class Client {

	int clientid;
	String clientname,clientaddress;

	Client()//Default constructor
	{
		
		
	}
Client(int clientid,String clientname,String clientaddress)//Parameterized constructor
{
	this.clientid=clientid;		//To avoid confusion between 2 same variables, we use "this."
	this.clientname=clientname;
	this.clientaddress=clientaddress;
}

 void display()
{
	System.out.println(clientid+" "+clientname+"  "+clientaddress);

}
public static void main(String[] args)
{
	Client c3=new Client();  //Calling default constructor
	Client c1=new Client(100,"Aditi","Mumbai"); //Calling 
	Client c2=new Client(101,"Prachi","Mumbai");
	c1.display(); //The sequence of printing depends on when display() function is called
	c3.display();
	c2.display();
	

	
}

}
