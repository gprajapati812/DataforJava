

	
	class Vehiclee implements Bikee,Carr,Auto
	{
	public void display()
	{
		System.out.println("Bike interface display method");
	}
	public void call()
	{
		System.out.println("car interface call method");
	}
	public void show()
	{
		System.out.println("Auto interface show method");
	}
}


interface Bikee{
	void display();
	default void disp()
	{
		System.out.println("printing concrete method using default");
	}
	
	static void statdisp()
	{
		System.out.println("printing concrete method using static");
		
	}
	
}
interface Carr{
	void call();
	
}
interface Auto{
	void show();
	
}

public class InterFace
{
	public static void main(String[] args) {
		Vehiclee v = new Vehiclee();
		v.show();
		v.call();
		v.display();
		v.disp();
		Bikee.statdisp();
	}

}