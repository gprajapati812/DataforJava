
 class Addition {
	
	int add(int a , int b)
	{
		return a+b;
	}
	
	int add(int a,int b, int c)
	{
		return a+b+c;
	}
}

public class Overloading_Add
{
	public static void main(String[] args) {
		
		Addition f = new Addition();
		int ans1 = f.add(10,10);
		int ans2 = f.add(10, 20, 30);
		System.out.println(ans1);
		System.out.println(ans2);
		
	}
}
