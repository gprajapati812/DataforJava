
public class Typecasting {
	
	public static void main(String[] args) {
		
		//implicit typecasting
		int i=100;
		long l = i;
		System.out.println(l);
		
		//Explicit typecasting
		double d=1000000.20;
		byte a= (byte) d;
		System.out.println(a);
				
	}

}
