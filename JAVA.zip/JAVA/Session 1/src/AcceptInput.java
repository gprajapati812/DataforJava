import java.util.Scanner;


public class AcceptInput {
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		//System.out.println("Enter your Employee id:");
		String name=sc.next();
		//System.out.println("Enter your name:");
		String surname=sc.next();
		//System.out.println("Enter your salary");
		char gender =sc.next().charAt(0);
		///System.out.println("Enter your grade");
		int age =sc.nextInt();
		//System.out.println("Enter phone number");
		Float wgh =sc.nextFloat();
		
		System.out.println("Person Details:\n_____________\n\nFirst Name: "+name+"\nLast Name: "+surname+"\nGender: "+gender+"\nAge: "+age+"\nWeight: "+wgh);
		
		
	}
}
