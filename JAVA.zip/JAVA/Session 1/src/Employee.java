
public class Employee {
	
	int empNo;
	String empName;
	static String compname="Capgemini";
	
	Employee(int e,String n)//This is parameterized constructor
	{				//Accepted the values in local variables and then passed to instance
		empNo=e;	//instance passed to local variable
		empName=n;
	}
	void display()
	{
		System.out.println(empNo+"    "+empName+"   "+compname);
		
	}
	
	
	public static void main(String[] args)
	{
		Employee e1=new Employee(111,"Abc");
		Employee e2=new Employee(112,"xyz");
		e1.display();
		e2.display();
		
	}
	}


