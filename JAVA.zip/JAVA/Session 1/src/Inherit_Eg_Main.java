
class Vehicle    //Parent class
{
	String color="blue";
		
		void brake()
		{
			
			 System.out.println("Super class method");
			
		}
}
		class Carrr extends Vehicle		//Child class
		{
			String color="red";
			void gear()
			{
				System.out.println(color);
				System.out.println(super.color);
				//System.out.println("Sub class method");
			}
		}
		
		class Bikeee extends Vehicle
		{
			
			void handle()
			{
				System.out.println("bike runs");
				
			}
			
		}
		
		public class Inherit_Eg_Main //This is main class where super and sub class are called
		{
			public static void main(String[] args) {
				
				Carrr c = new Carrr();
				Bikeee b = new Bikeee();
				Vehicle v = new Vehicle();
				c.brake();
				c.gear();
				System.out.println(c instanceof Vehicle);  // does car inherit vehicle
				System.out.println(b instanceof Vehicle);	//does bike inherit vehicle
				System.out.println(v instanceof Carrr);		//does vehicle inherit car
				System.out.println(v instanceof Object);	//does vehicle inherit Object
			}
			
		}
		
		
