
 class Additionn {
	
	int add(int a , int b)
	{
		return a+b;
	}
	
	float add(float a,float b)
	{
		return a+b;
	}
}
public class Overloading_datatype {
	
public static void main(String[] args) {
		
		Additionn f = new Additionn();
		int ans1 = f.add(10,10);
		float ans2 = f.add(10.5f, 20.5f);
		System.out.println(ans1);
		System.out.println(ans2);
		
	}

}
