
	abstract class Shape{		//abstract class

		abstract void display(); //abstract method
		abstract void show(); //abstract method
	
		void call()	//concrete or normal method
		{
			System.out.println("Concrete Method");	
		}
	}	
		class Circle extends Shape		//subclass
		{
			void display()
			{
				System.out.println("Display circle");
			}
		
			void show()
			
			{
				
				System.out.println("Show circle");
			}
		}	
	class  AbstractEg_Shape				//main class
	{
		public static void main(String[] args) {
			Shape s = new Circle();
			s.display();
			s.show();
			System.out.println("___________");
			Circle c = new Circle();
			c.display();
			s.show();
			System.out.println("___________");
			Circle d = (Circle) new Object();
			d.display();
			d.show();
			//s.call();
		}
		
	}

