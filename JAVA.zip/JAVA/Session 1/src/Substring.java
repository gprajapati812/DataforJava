
public class Substring {

	public static void main(String[] args) {
		
		String s ="Aditi Dumbre";
		
		StringBuffer sb = new StringBuffer();  //used to mute String class
		sb.append(s.substring(6));
		sb.append(", ");
		sb.append(s.substring(0,1));
		System.out.println(sb);
		
	}
	
}
