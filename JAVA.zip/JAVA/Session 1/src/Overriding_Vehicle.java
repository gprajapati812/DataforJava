
class Car		//overriding example
{
	public void speed()
	{
		System.out.println("car class");
	}
}
class Bike extends Car
{
	public void speed()
	{
		System.out.println("Bike class");
	}
}

public class Overriding_Vehicle {
	
	public static void main(String[] args) {
		
	
	Bike b = new Bike();
	Car c = new Car();
	c.speed();
	b.speed();
	}
}
