import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;


public class DateFunctions {

			public static void main(String[] args) {
				
				LocalDate d = LocalDate.now();
				LocalDate d1 = LocalDate.of(2016, Month.SEPTEMBER, 21);
			/*	System.out.println(d1);
				System.out.println(d.getYear());
				System.out.println(d.getYear());
				System.out.println(d.getDayOfMonth());
				System.out.println(d.plusDays(2));
				System.out.println(d.getDayOfWeek());*/
				
				String s="31-12-2017";
				DateTimeFormatter df=DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate dd = LocalDate.parse(s,df);
				System.out.println(dd);
			}
}
