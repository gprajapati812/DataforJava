//sorting array based on salary
public class EmpCompare implements Comparable<EmpCompare>{
	
	
	@Override  //it prints object generated output..so override it using override tostring
	public String toString() {
		return "EmpCompare [eid=" + eid + ", ename=" + ename + ", salary="
				+ salary + "]";
	}

	int eid;
	String ename;
	int salary;

	public EmpCompare(int eid, String ename, int salary) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.salary = salary;
	}
	
	

	@Override
	public int compareTo(EmpCompare e) { //We get this override method by right click on EmpCompare
		if(salary == e.salary)
		{
			return 0;
		}
		else if(salary > e.salary)
		{
			return 1;
		}
		else
		{
			return -1;
		}
		
	}

	
}
