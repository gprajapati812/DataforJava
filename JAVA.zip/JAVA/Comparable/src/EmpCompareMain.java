import java.util.ArrayList;
import java.util.Collections;


public class EmpCompareMain {
	public static void main(String[] args) {
		
		ArrayList<EmpCompare> al=new ArrayList<EmpCompare>();
		al.add(new EmpCompare(101,"Adi",25000));
		al.add(new EmpCompare(102,"yogz",27000));
		al.add(new EmpCompare(103,"keems",29000));
		Collections.sort(al);
		
		
		
		for(EmpCompare e:al)
		{
			System.out.println(e);
		}
	}
}
