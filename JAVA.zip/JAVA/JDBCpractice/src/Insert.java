import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;


public class Insert {
	
public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg301","training301");
		//("jdbc:oracle:thin:@localhost:1521:xe","trg301@orcl","training301");
		
		
		
		PreparedStatement ps=con.prepareStatement("insert into emp values(?,?,?,?,?,?,?,?)");
		ps.setInt(1, 1005);
		ps.setString(2, "adiii");
		ps.setString(3, "Engg");
		ps.setInt(4, 1);
		ps.setString(5, "25-DEC-1995");		//Insert date using string
		ps.setFloat(6, 2500.5f);			//Insert float
		ps.setFloat(7,  20.5f);
		ps.setInt(8,2);
		
		
		
		
		int r = ps.executeUpdate();
		System.out.println(r+"  rows inserted");
		
		
		
}
}