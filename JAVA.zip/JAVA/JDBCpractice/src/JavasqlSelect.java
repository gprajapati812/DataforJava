import java.sql.*;


public class JavasqlSelect {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg301","training301");
		//("jdbc:oracle:thin:@localhost:1521:xe","trg301@orcl","training301");
		
		Statement stmt=con.createStatement();
		
		ResultSet rs=stmt.executeQuery("select * from mobiles");
		
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getString(2));
		}
		con.close();
		
	}

}
