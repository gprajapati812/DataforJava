import java.util.*;

public class ArrayMethod {
		public static void main(String[] args) {
			
			Scanner sc = new Scanner(System.in);
			Sort s = new Sort();
			
			System.out.println("Enter the number of products");
			int count = sc.nextInt();
			String product[] = new String[count];
			
			System.out.println("Enter products");
			for(int i=0;i<count;i++)
			{
				product[i]=sc.next();
			}
			
			s.SortArray(product);	
		}
}

class Sort{
void SortArray(String[] product)
	{
		Arrays.sort(product);
		System.out.println("After sorting");
		for(String out:product)
		{
			System.out.println(out);
		}
	}
}
