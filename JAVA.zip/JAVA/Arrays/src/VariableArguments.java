
public class VariableArguments {

	public static void fun(int a,String ...c)
	{
		System.out.println(a);
		for(String out:c)
		{
			System.out.println(out);
		}
		
	}
	public static void main(String[] args) {
		fun(5,"10","20","adi");
	}
}
