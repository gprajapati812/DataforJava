import java.util.Arrays;
import java.util.Scanner;


public class MinMax {

	public static void main(String[] args) {
		
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of array");
	int n=sc.nextInt();
	int a[] = new int[n];
	
	System.out.println("Enter "+n+" elements");
	
	for(int i=0;i<a.length;i++)
	{
		a[i]=sc.nextInt();
	}
	
	Arrays.sort(a);
	System.out.println("Sorted elements");
	for(int i=0;i<a.length;i++)
	{
		System.out.print(a[i]+" ");
	}
	int min=a[0];
	int max=a[a.length-1];
	System.out.println("\nmin + max is");
	System.out.println(min+max);
	
	System.out.println("middle element\n"+a[a.length/2]);
	//FOR EACH LOOP
	System.out.println("Sorting using for each loop");
	for(int out: a)
	{
		System.out.print(out+" ");
	}
	}
}
