import java.util.Scanner;


public class UnitPlace {

	public static void main(String[] args) {
		
		int unit1;
		int unit2;
		
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter the first number");
	int a = sc.nextInt();
	
	System.out.println("Enter the second number");
	int b= sc.nextInt();
	
	unit1 = a%10;
	unit2 = b%10;
	
	if(unit1 == unit2)
	{
		System.out.println("true");
	}
	else
	{
		System.out.println("false");
	}
	
	}
}
