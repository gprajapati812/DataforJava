package BankApplication;

import java.util.Scanner;
import java.util.regex.Pattern;

public class AccountDetails {
	
	Scanner sc = new Scanner(System.in);
	public void aDetails()
	{
		System.out.println("Enter your Account Details:");
		
		System.out.println("Enter your Account Number:");
		String anumber = sc.next();
		String anumreg="[0-9]{0,10}";
		boolean snumbervalidate = Pattern.matches(anumreg, anumber);
		validateStatus(snumbervalidate);
		
		System.out.println("Enter Account holder name:");
		String aname = sc.next();
		
		System.out.println("Enter the Account type");
		String atype = sc.next();
		
		System.out.println("Your Account details are:");
		System.out.println("Your Account Number is :"+anumber);
		
		System.out.println("Account holder name is :"+aname);

		System.out.println("Your Account type is :"+atype);
	}
	public void validateStatus(boolean status)
	{
		if(status==false)
		{
			System.out.println("The input you entered does match the requested pattern");
			System.exit(0);
		}
	}
}
