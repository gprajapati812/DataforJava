package BankApplication;

import java.util.Scanner;
import java.util.regex.Pattern;


public class BankDetails {
	
	Scanner sc = new Scanner(System.in);
	//BankDetails bd = new BankDetails();
	public void bDetails()
	{
	
		System.out.println("Banks Details");
		System.out.println("Enter your name:");
		String bname = sc.nextLine();
		
		System.out.println("Enter your IFSC code:");
		String ifsc = sc.next();
		String ifscreg="[A-Z]{3}[0-9]{1,5}";
		boolean ifscvalidate = Pattern.matches(ifscreg, ifsc);
		validateStatus(ifscvalidate);
		
		System.out.println("Enter your branch location:");
		String bloc = sc.next();
		String blocreg="[A-Za-z]{0,5}";
		boolean blocvalidate = Pattern.matches(blocreg, bloc);
		validateStatus(blocvalidate);

		System.out.println("Your Bank details are:");
		System.out.println("Your name is :"+bname);
		
		System.out.println("Your IFSC code is :"+ifsc);

		System.out.println("Your branch location :"+bloc);
	}
	
	public void validateStatus(boolean status)
	{
		if(status==false)
		{
			System.out.println("The input you entered does match the requested pattern");
			System.exit(0);
		}
	}
	
}
