package BankApplication;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Bank Application Details:");
		System.out.println("Select an option:\n1.Bank Details\n2.Account Details\n3.Exit");
		int choice=sc.nextInt();
		
		BankDetails b = new BankDetails();
		AccountDetails a = new AccountDetails();
		
		
		switch (choice)
		{
		case 1: b.bDetails();
				break;
			
		case 2:	a.aDetails();
				break;
		
		case 3:	System.out.println("You successfully exited the application");
				break;
			
		default:System.out.println("Invalid choice");
		}
		
		
	}
}

