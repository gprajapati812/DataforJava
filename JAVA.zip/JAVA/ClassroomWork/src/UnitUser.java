
public class UnitUser {
		
	public static boolean display(int a,int b)
	{
		
		int unit1 = a%10;
		int unit2 = b%10;
		
		if(unit1 == unit2)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
