package com.cg.main;

public interface IEmployee {	//Interface

	void insert();
	void retrieve();
	void display();
}
