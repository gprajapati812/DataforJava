package com.cg.main;

class Operations implements IEmployee { //subclass
	
		
		public void display()
		{
			System.out.println("i displayed");
		}
		public void insert()
		{
			System.out.println("i inserted data");
		}
		public void retrieve()
		{
			System.out.println("i retrieve");
		}

}
public class EmployeeImplemnt	//main class
{
	public static void main(String[] args) {
		
		Operations o = new Operations();
		o.display();
		o.insert();
		o.retrieve();
		
	}
}