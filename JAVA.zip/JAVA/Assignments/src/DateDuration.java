import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class DateDuration {

public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		DateTimeFormatter pd = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter the date");
		String purchasedate = sc.next();
		LocalDate start = LocalDate.parse(purchasedate,pd); 
		//LocalDate start = LocalDate.of(1947,Month.AUGUST,15);
		LocalDate end = LocalDate.now();
		
		Period period = start.until(end);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	}
}
