import java.util.Scanner;


public class StringOperations {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the String");
		String str = sc.next();
		
		System.out.println("Select the choice of operation");
		System.out.println("1.Append String\n2.Replace odd position by #\n3.Remove duplicate letter\n4.Change odd characters to upper case\n");
		
		int choice=sc.nextInt();
		
		StringOperations s = new StringOperations();
		
		switch (choice)
		{
		case 1 : s.append(str);
					break;
		case 2 : s.replace(str);
					break;
		case 3 : s.removeDuplicate(str);
					break;
		case 4 : s.oddToUpper(str);
					break;
		default : System.out.println("Invalid number");
		}
		
	}

	void append(String str)
	{
		
		//System.out.println("1");
		StringBuffer sb = new StringBuffer();
		sb.append(str.substring(0));
		sb.append(str.substring(0));
		System.out.println(sb);
		
	}
	
	void replace(String str)
	{
		System.out.println("2");
		StringBuilder ss = new StringBuilder(str);
		for(int i=0;i<str.length();i++)
		{
			if(i%2!=0)
			{
				//System.out.println("k");
				 char currChar = str.charAt(i);
				 	//System.out.println(currChar);
			        int idx = str.indexOf(currChar);
			        //if (idx != -1) 
			        ss.setCharAt(i, '#');
			}
		}
		System.out.println(ss);
	}
	void removeDuplicate(String str)
	{
		char [] temp = str.toCharArray();
	
		int length =temp.length; 
		
		for (int i=0;i<length;i++)
	    {
	        for (int j = i+1; j<length;j++)
	        {
	            if(temp[i]==temp[j])
	            {
	                int test =j;
	                for(int k=j+1; k<length ; k++)
	                {
	                    temp[test] = temp[k];
	                    test++;
	                }
	                length--;
	                j--;
	            }
	        }
	    }
		 System.out.println( String.copyValueOf(temp).substring(0,length));
	}
	void oddToUpper(String str)
	{
		//System.out.println("4");
		for(int i=0;i<str.length();i++)
		{
			char ch = str.charAt(i);
			if(i%2!=0)
			{
				
				System.out.print(Character.toUpperCase(ch));
			}
			else
			{
				System.out.print(Character.toLowerCase(ch));
			}
		}
		
	}

}