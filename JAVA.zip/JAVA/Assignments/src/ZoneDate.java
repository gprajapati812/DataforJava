import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;


public class ZoneDate {
		public static void main(String[] args) {
			DateTime dt = new DateTime();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter a place");
			String place = sc.next();
			ZonedDateTime d = dt.returnDateTime(place);
			System.out.println(d);
			
		}
}
class DateTime
{
	ZonedDateTime returnDateTime(String place)
	{
		ZonedDateTime d = ZonedDateTime.now(ZoneId.of(place));
		return d;
	}
}