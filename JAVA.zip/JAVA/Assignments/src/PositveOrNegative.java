import java.util.Scanner;


public class PositveOrNegative {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a number");
		int num = sc.nextInt();
		
		if(num<0)
		{
			System.out.println("You entered a negative number");
		}
		else if(num>0)
		{
			System.out.println("You enterd a positive number");
		}
		else
		{
			System.out.println("You entered zero");
		}
	}
}
