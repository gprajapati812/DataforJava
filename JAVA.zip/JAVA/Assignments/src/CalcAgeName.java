import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class CalcAgeName {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		CalcAgeName c = new CalcAgeName();
		
		
		
		System.out.println("Enter your first name");
		String firstName = sc.next();
		
		System.out.println("Enter your Last name");
		String lastName = sc.next();
		
		StringBuffer fullname = c.getFullName(firstName,lastName);
		int age = c.calculateAge();
		System.out.println("Person Details:\n___________________");
		System.out.println("Name: "+fullname);
		System.out.println("Age: "+age+" years");
		
	}
	
	int  calculateAge()
	{
		Scanner sc = new Scanner(System.in);
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter the date of birth");
		String dob = sc.next();
		
		LocalDate start = LocalDate.parse(dob,df); 
		LocalDate end = LocalDate.now();
		
		Period period = start.until(end);
		
		int age = period.getYears();
		return age;
		
	}
	
	StringBuffer getFullName(String firstName, String lastName)
	{
		StringBuffer sb = new StringBuffer();
		sb.append(firstName.substring(0));
		sb.append(" ");
		sb.append(lastName.substring(0));
		//System.out.println(sb);
		return sb;
	}
}
