	import java.time.LocalDate;
	import java.time.Month;
	import java.time.Period;
	import java.time.format.DateTimeFormatter;
	import java.util.Scanner;

public class TwoDateDuration {


	public static void main(String[] args) {
			
			Scanner sc = new Scanner(System.in);
			
			DateTimeFormatter ps = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			System.out.println("Enter the start date");
			String startdate = sc.next();
			
			DateTimeFormatter pe = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			System.out.println("Enter the end date");
			String enddate = sc.next();
			
			LocalDate start = LocalDate.parse(startdate,ps); 
			LocalDate end = LocalDate.parse(enddate,pe); 
			
			Period period = start.until(end);
			
			System.out.println("Days:"+ period.getDays());
			System.out.println("Months:"+period.getMonths());
			System.out.println("Years:"+ period.getYears());
		}
	

}
