import java.util.Scanner;


public class PositiveString {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the string");
		String s = sc.next();
		
		int flag = 0;
		//char [] temp = s.toCharArray();
		
		//int temp_asci = ascii;
		for(int i=0;i<s.length();i++)
		{
			for(int j=i+1;j<s.length();j++)
			{
			char frst = s.charAt(i);
			int ascii = (int) frst; 
			
			char nxtch = s.charAt(j);
			int nxtascii = (int) nxtch;
			
			if(ascii > nxtascii)
			{
				flag=1;
				break;
			}
			
			}
			
		}
		if(flag==1)
		{
			System.out.println("Negative value");
		}
		else
		{
			System.out.println("Positive value");
		}
	}
}
