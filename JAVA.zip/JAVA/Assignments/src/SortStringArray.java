import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class SortStringArray {
	
	public static void main(String[] args) {
		
	
	Scanner sc = new Scanner(System.in);
	ArrayList<String> a1 = new ArrayList<String>();
	System.out.println("Enter the products");
	a1.add(sc.next());
	a1.add(sc.next());
	a1.add(sc.next());
	a1.add(sc.next());
	a1.add(sc.next());
	
	Collections.sort(a1);
	
	System.out.println("The sorted products list is");
	for(String a:a1)
	{
		System.out.println(a);
		
	}

	}
}
