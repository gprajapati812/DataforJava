import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.Month;

import javax.swing.text.DateFormatter;

public class WaranteeExpiration {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		WaranteeExpiration w = new WaranteeExpiration();
		
		//To accept the date input
		DateTimeFormatter pd = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter the date");
		String purchasedate = sc.next();
		LocalDate ld = LocalDate.parse(purchasedate,pd); 
		
		int pyear = ld.getYear();
		int pmonth = ld.getMonthValue();
		int pday = ld.getDayOfMonth();
		
		
		System.out.println("Enter the months of warantee");
		int wmonth =sc.nextInt();
		System.out.println("Enter the year of warantee");
		int wyear =sc.nextInt();
		
		w.calcExpiry(pyear,pmonth,pday,wyear,wmonth);
		
	}
	
	void calcExpiry(int pyear, int pmonth,int pday,int wyear,int wmonth)
	{
		 int months=pmonth + wmonth;
		 int years=pyear + wyear;
		 
		 if( months > 12)
		 {
			months = months - 12;
			years = years + 1;
			System.out.println(months+"/"+years);
		 }
		 else
		 {
			
			 System.out.println(months+"/"+years);
		 }
		 
		 
	}
}
	
