import java.util.Arrays;
import java.util.Scanner;


public class SortProducts {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of products");
		int count = sc.nextInt();
		String product[] = new String[count];
		
		System.out.println("Enter products");
		for(int i=0;i<product.length;i++)
		{
			product[i]=sc.next();
		}
		
		Arrays.sort(product);
		
		System.out.println("After sorting");
		for(int i=0;i<product.length;i++)
		{
			System.out.print(product[i]+" \n");
		}
			
		
	}
}
