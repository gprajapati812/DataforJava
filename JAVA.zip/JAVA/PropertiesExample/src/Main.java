import java.io.*;
import java.sql.*;

public class Main {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
			Connection con=DBUtil.getConnection();
			
			PreparedStatement ps=con.prepareStatement("insert into emp values(?,?,?,?,?,?,?,?)");
			ps.setInt(1, 1006);
			ps.setString(2, "pachi");
			ps.setString(3, "Engg");
			ps.setInt(4, 2);
			ps.setString(5, "08-DEC-1995");		//Insert date using string
			ps.setFloat(6, 2500.5f);			//Insert float
			ps.setFloat(7,  20.5f);
			ps.setInt(8,3);
			
			
			
			
			int r = ps.executeUpdate();
			System.out.println(r+"  rows inserted");
			
			
			
	}
	
}
