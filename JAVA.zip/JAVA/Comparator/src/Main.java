import java.util.ArrayList;


public class Main {
	public static void main(String[] args) {
		ArrayList<Employe> a1=new ArrayList<Employe>();
		a1.add(new Employe(103,"mohit",2500.98));
		a1.add(new Employe(101,"amit",3500.21));
		a1.add(new Employe(102,"kiran",45000.88));
		Collections.sort(a1, new SortById());
		System.out.println("Based on Employee if sorting");
		
		for(Employe e:a1)
		{
			System.out.println(e);
		}
		
		System.out.println("Based on employee salary sorting");
		Collections.sort(a1, new SortBySalary());
		for(Employe e:a1)
		{
			System.out.println(e);
		}
	}
}
