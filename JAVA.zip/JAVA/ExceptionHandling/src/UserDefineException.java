class AgeInvalidException extends Exception{
	
	public AgeInvalidException(int age)
	{
		super(age);
	}
}
public class UserDefineException {

	static void ageCheck(int age) throws AgeInvalidException{
		
	}
	
	public static void main(String[] args) {
		
		try
		{
			ageCheck(-2);
		}
		catch(AgeInvalidException a)
		{
			System.out.println("Invalid Age");
		}
	}
}
