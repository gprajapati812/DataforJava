
public class ThrowClause {

	
		public static void checkAge(int a){
		
		if (a<18)
		{
			throw new ArithmeticException("Invalid Age");
		}
		else
		{
			System.out.println("Valid exception");
		}
			
	}
public static void main(String[] args) {
	
	try{
	ThrowClause.checkAge(20);
	}
	catch(Exception e)
	{
		System.out.println("Invalid age, printed in catch block");
	}
	}
	
}
	

