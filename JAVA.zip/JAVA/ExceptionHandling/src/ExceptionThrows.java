import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ExceptionThrows {
	
	public static void main(String[] args) throws ParseException //declaring exception by right clicking on sdf.parse error
	{
		
		String s ="10.12.2012";
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
		Date d1 = sdf.parse(s);	//This line will show error and will always need throws exception declaration or try catch exception handling
		System.out.println(d1);
	}

}
