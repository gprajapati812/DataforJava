
public class Exceptn {

	public static void main(String[] args) {
		
		try{
				int a= 10/0;
				//int b[] = new int[5];
				//b[6]=654;
		}
		
		catch(ArrayIndexOutOfBoundsException b)
		{
			System.out.println("Out of bound");
			//b.printStackTrace(); //THis prints the line no. of exception
		}
		catch(ArithmeticException u)
		{
			System.out.println("This is divide by 0 exception");
		}
		catch(Exception e) //This can handle all exceptions.It is a ancester of other exception sublasses.
							//it shud b written at end of all catch block
		{
			System.out.println("Invalid input");
			
		}
		finally
		{
			System.exit(0);	//This line does not let finally block executer
			System.out.println("i will be always executed");
			
		}
		
	}
}
