 package com.cg;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class PersonUtil {

	public static void main(String[] args) throws IOException, SQLException {
		
		PersonUtil.getConnection();
		
	}
	

	public static void getConnection() throws IOException, SQLException{
	
		Connection con = null;
		Properties pro = readDbInfo(); 
		
		String url = pro.getProperty("url");
		String password = pro.getProperty("password");
		String username = pro.getProperty("username");
		
		System.out.println("URL : "+url);
		System.out.println("User Name : "+username);
		System.out.println("Password : "+password );
		
		//con = DriverManager.getConnection(url,username,password);
		
		//return con;
	}

	private static Properties readDbInfo() throws IOException {

			Properties p = new Properties();
			
			FileReader fr = new FileReader("PersonPros.properties");
			p.load(fr);
			
		return p;
	}
	
	
}
