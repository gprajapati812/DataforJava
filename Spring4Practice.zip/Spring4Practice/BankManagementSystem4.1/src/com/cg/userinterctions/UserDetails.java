package com.cg.userinterctions;

import com.cg.acct.Account;

public class UserDetails {

public static void main(String[] args) {
		
	Account sm = new Account();
	Account kt = new Account();
	
	// a) Create Account for smith with initial balance as INR 2000 and for Kathy with initial balance as 3000.
	sm.setName("Smith");
	sm.setAge(22); // accNum should be auto generated
	sm.setBalance(2000);
	Account.setAccNum();
	System.out.println(sm.toString(sm));

	
	kt.setName("Kathy");
	kt.setAge(21); // accNum should be auto generated
	Account.setAccNum();
	kt.setBalance(3000);
	
	System.out.println(kt.toString(kt));
	
	
	// b) Deposit 2000 INR to smith account.
	sm.deposite(2000);
	System.out.println(sm.toString(sm));
	
	// c) Withdraw 2000 INR from Kathy account.
	
	kt.withdraw(2000);
	System.out.println(kt.toString(kt));
	kt.withdraw(1500);
	
	}
}
