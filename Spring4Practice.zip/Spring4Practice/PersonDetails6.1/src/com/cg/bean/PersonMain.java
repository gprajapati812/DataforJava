package com.cg.bean;

import java.util.Scanner;

import java.lang.Exception;

public class PersonMain  {

	Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
	
	PersonMain pm = new PersonMain();
		
	Person p1 = new Person("Govind","Parajapati",'M'); // set data with constructor
		System.out.println(p1.toString()); // calling toString() to print data
		
		try {
			pm.acceptData();
		} catch (PersonException e) {
			// TODO Auto-generated catch block
			System.out.println("Cought Exception ---- " +e);
		}
		
	}
	
	
	void acceptData() throws PersonException
	{
		Person p = new Person();
		
		System.out.println("Enter First name");
		String fName = sc.nextLine();
		if(fName.equals("") || fName==null)
			throw new PersonException(fName);
		p.setfName(fName);
		
		System.out.println("Enter Last name");
		String lName = sc.nextLine();
		if(lName.equals("") || lName == null)
			throw new PersonException(lName);
		p.setlName(lName);
		
		System.out.println("Enter Gender");
		char gen = sc.next().charAt(0);
		p.setGender(gen);
		
	}
	
	
}

class PersonException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String data;
	
	PersonException(String args)
	{
			data = args;
	}

	@Override
	public String toString() {
		return "Person Exception: Name cannot be empty..... ";
	}
	
}


