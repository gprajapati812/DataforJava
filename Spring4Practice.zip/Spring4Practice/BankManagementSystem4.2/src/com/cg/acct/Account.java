package com.cg.acct;

import com.cg.person.Person;

public abstract class Account extends Person{

	private static long accNum = 1081810;
	protected double balance;
	private Person accHolder;
	
	public long getAccNum() {
		return accNum;
	}
	public static void setAccNum() {
		Account.accNum ++ ;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public abstract void deposite(double amt);
	public abstract void withdraw(double amt);
	public abstract boolean isBalanceAvailable(double amt, double balance);

	public String toString(Account ac) {
		return "----------------------------------------------\nAccount Number : "+ac.getAccNum()+"\nAccount Name : "+ac.getName()+"\nAccount Balance : "+ac.getBalance();
	}

}
