package com.cg.userinterctions;

import com.cg.acct.Account;
import com.cg.acct.CurrentAccount;
import com.cg.acct.SavingAccount;


public class UserDetails {

public static void main(String[] args) {
		
	SavingAccount sa = new SavingAccount();
	CurrentAccount ca = new CurrentAccount();
	
	// a) Create Account for smith with initial balance as INR 2000 and for Kathy with initial balance as 3000.
	sa.setName("Smith");
	sa.setAge(22); // accNum should be auto generated
	sa.setBalance(2000);
	Account.setAccNum();
	System.out.println(sa.toString(sa));

	
	ca.setName("Kathy");
	ca.setAge(21); // accNum should be auto generated
	Account.setAccNum();
	ca.deposite(0); // to set OverDraftLimit
	
	System.out.println(ca.toString(ca));
	
	
	// b) Deposit 2000 INR to smith account.
	sa.deposite(2000);
	System.out.println(sa.toString(sa));
	sa.withdraw(5000);
	
	// c) Withdraw 2000 INR from Kathy account.
	
	ca.withdraw(2000);
	System.out.println(ca.toString(ca));
	ca.withdraw(1500);
	System.out.println(ca.toString(ca));
	
	ca.withdraw(9000); // to check overdraft limit
	
	}
}
