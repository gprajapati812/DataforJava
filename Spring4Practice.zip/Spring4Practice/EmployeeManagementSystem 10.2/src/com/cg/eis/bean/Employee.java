package com.cg.eis.bean;

import java.util.Comparator;

import com.cg.eis.service.InsuranceScheme;


public class Employee implements Comparator<Employee> {

	private int eId;
	private String eName;
	private String eDesign;
	private String eInsuraceScheme;
	private double eSalary;
	static int l = 1234;
	
	public Employee()
	{
		this.eId = Employee.l++;
		this.eName = "Unknown";
		this.eDesign = "Unknown";
		this.eInsuraceScheme = "Unknown";
		this.eSalary = 0.0;
	}
	
	InsuranceScheme ic = new InsuranceScheme();
	
	
	public Employee(String eName, String eDesign, double eSalary) {
		this.eId = Employee.l++;
		this.eName = eName;
		this.eDesign = eDesign;
		this.eSalary = eSalary;
		
		ic.calculateInsuranceScheme(this);		
	}



	public int geteId() {
		return eId;
	}



	public String geteName() {
		return eName;
	}




	public String geteDesign() {
		return eDesign;
	}

	public String geteInsuraceScheme() {
		return eInsuraceScheme;
	}
	public void seteInsuraceScheme(String eInsuraceScheme) {
		this.eInsuraceScheme = eInsuraceScheme;
	}
	public double geteSalary() {
		return eSalary;
	}


	@Override
	public String toString() {
		return "\n\nEmployee Details\n-------------------------------\n"
				+"Employee Id: "+eId+""
				+"\nEmployee Name: "+eName
				+"\nEmployee Designation: "+eDesign
				+"\nEmployee Salary: "+eSalary
				+"\nEmployee Insurance Scheme: "+geteInsuraceScheme();
	
	}



	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return (int) (o1.geteSalary() - o2.geteSalary());
	}

	
}
