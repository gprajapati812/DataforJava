package com.cg.eis.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	double emp_sal;
	
	public EmployeeException(double emp_sal)
	{
		this.emp_sal = emp_sal;		
	}

	@Override
	public String toString() {
		return "EmployeeException: Employee Salary " + emp_sal + " must be more than 3000";
	}
	
	
}
