package com.cg.day1;

import java.util.Scanner;

public class CheckNegativeNumber {

	public static void main(String[] args) {
		Number n = new Number();
		n.setInput();
		n.validateInput();
	}

}

class Number
{
	
	
	Scanner sc  = new Scanner(System.in);
	
	float input;
	void setInput()
	{
		System.out.println("Enter number");
		input = sc.nextInt();
	}
	
	boolean checkInput(float input)
	{
		if(input < 0)
			return false;
		else
			return true;
	}
	
	void validateInput()
	{
		if(checkInput(input))
		{
			System.out.println("Input is Positive Number");
		}
		else
		{
			System.out.println("Input is Negative Number");
		}
			
		
	}
	
	
}
