package com.cg.day1;

public class Client {
	
	int clientId;
	String clientName;
	String clientAddress;
	
	Client()
	{}
	
	Client(int clientId,String clientName,String clientAddress)
	{
		this.clientId = clientId;
		this.clientName = clientName;
		this.clientAddress = clientAddress;
	}
	
	void printData()
	{
		System.out.println("Client Id : "+clientId);
		System.out.println("Client Name : "+clientName);
		System.out.println("Client Address : "+clientAddress);
		
		
	}


	public static void main(String[] args) {
	/*	Client c1 = new Client();
		Client c2 = new Client(101,"Govind","Mumbai");

		Student.setDept("Comp");
		
		Student s1 = new Student(10,"Govind");
		Student s2 = new Student(20,"Suresh");
		s1.display();
		s2.display();
		

		c1.printData();
		c2.printData();*/
		
		
		EmployeeDetails ed = new EmployeeDetails();
		ed.setEmpDetaiils();
		ed.printEmpDetails();

	
}
	
}

