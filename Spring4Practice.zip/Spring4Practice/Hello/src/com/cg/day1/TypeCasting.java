package com.cg.day1;

public class TypeCasting {

	public static void main(String[] args) {
		
		int i = 500;
		long l = i;
		System.out.println(l);
		
		double f = 200.53;
		
		int d = (int) f;
		
		System.out.println(d);
				
		
	}
	
	
}
