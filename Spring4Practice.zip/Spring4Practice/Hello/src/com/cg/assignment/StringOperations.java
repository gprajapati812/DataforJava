package com.cg.assignment;

import java.util.Scanner;

public class StringOperations {

	public static void main(String[] args) {
		Operations o = new Operations();
		o.getUserCoice();
	}
	
	
}


class Operations
{
	Scanner sc= new Scanner(System.in);
	
	int userChoice;
	String userInput;
	char in;
	void getUserCoice()
	{
		
		do{
		
		System.out.println("Enter String ");
		userInput = sc.next();
		
		System.out.println("Enter your Choice : \n1:Add String \n2:Replace Odd Position \n3:Remove Duplicate character \n4:Change odd character to Upper");
		userChoice =  sc.nextInt();
		switch(userChoice)
		{
		case 1:
			addString(userInput);
		break;
	
		case 2:
			replaceOddPosition(userInput);
		break;
		
		case 3:
			removeDuplicateChar(userInput);
		break;

		case 4:
			changeOddToUpper(userInput);
		break;
		default:
			System.out.println("Wrong Choice");
		}
		
		System.out.println("Do you want to continue Y/N");
		 in = sc.next().charAt(0);
		 if(in == 'n' || in == 'N')
			 break;
		}
		while(true);
		System.out.println("Thank You !!!!");
	}

	private void changeOddToUpper(String input) {
		StringBuffer sb = new StringBuffer();
		// TODO Auto-generated method stub
		 for (int i=0; i < input.length(); i++){
		        if (i % 2 != 0){
		        	String s = input.substring(i,i+1).toUpperCase();
		        	sb.append(s);
		        }
		        else
		        {
		        	String s = input.substring(i,i+1);
		        	sb.append(s);
		        
		        }
		 }
		 
		 System.out.println("String with # : "+sb.toString());
	}

	private void removeDuplicateChar(String input) {
		/*  String result = "";
		    for (int i = 0; i < input.length(); i++) {
		        if(!result.contains(String.valueOf(input.charAt(i)))) {
		            result += String.valueOf(input.charAt(i));
		        }
		    }*/
		
		  int res_ind = 1, ip_ind = 1;
	         
	        // Character array for removal of duplicate characters
	        char arr[] = input.toCharArray();
	         
	        /* In place removal of duplicate characters*/
	        while (ip_ind != arr.length)
	        {
	            if(arr[ip_ind] != arr[ip_ind-1])
	            {
	                arr[res_ind] = arr[ip_ind];
	                res_ind++;
	            }
	            ip_ind++;
	           
	        }
	     System.out.println(res_ind);
	     System.out.println(input.length());
	        input = new String(arr);
	        input =  input.substring(0,res_ind);
		    
		    System.out.println("String After Removing Duplicates : "+input);
		 }
		 


	private void replaceOddPosition(String input) {
		// TODO Auto-generated method stub
		 for (int i=0; i < input.length(); i++){
		        if (i % 2 != 0){
		        	input = input.substring(0,i-1) + "#" + input.substring(i, input.length());
		        }
		 }
		 
		 System.out.println("String with # : "+input);
	}

	private void addString(String input) {
		// TODO Auto-generated method stub
		
		input = userInput +" "+ input;
		System.out.println("String After Addind : "+input);
	}

}