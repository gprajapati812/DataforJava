package com.cg.assignment;

import java.util.Scanner;

public class PositiveString {

	public static void main(String[] args) {
		
		StringPositiveOp op = new StringPositiveOp();
		op.acceptData();
		op.checkPositive();
	}
	
	
}


class StringPositiveOp
{
	
	Scanner sc  =  new Scanner(System.in);
	
	String str = null;
	void acceptData()
	{
		System.out.println("Enter String to check Positive or negative: ");
		str = sc.next();
		System.out.println("Entered String "+str);
	}
	
	void checkPositive()
	{
		if(checkString(str))
		{
			System.out.println("Given String is Positive String ");
		}
		else
			System.out.println("Given String is not Positive String ");
	}

	 boolean  checkString(String str) {
		// TODO Auto-generated method stub
		
		for(int i = 0;i<str.length()-1;i++)
		{
			if(str.charAt(i) > str.charAt(i+1))
				break;
			else
				return true;
		}
		return false;
	}

}