package com.cg.assignment;



public class Person {

	private String fname;
	private String lname;
	private long phonenumber;
	private char gender;
	private long age;

	
	/*Person(){}
	
	
	
	public Person(String fname, String lname, char gender) {
		this.fname = fname;
		this.lname = lname;
	}


*/
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		
		this.gender = gender;
	}



	public long getPhonenumber() {
		return phonenumber;
	}



	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}
	public long getAge() {
		return age;
	}
	public void setAge(long age) {
		this.age = age;
	}


	
}
