package com.cg.main;

public class EmployeeDetails
{
	
	public static void main(String[] args) {
		
		Employee e = new Employee();
		e.insert();
		e.display();
		e.retrieval();
		
	}
}

class Employee implements InterfaceEmployee{

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		System.out.println("Employee Inserted");
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Employee Display");
	}

	@Override
	public void retrieval() {
		// TODO Auto-generated method stub
		System.out.println("In Employee Retrieval");
	}

	
}
