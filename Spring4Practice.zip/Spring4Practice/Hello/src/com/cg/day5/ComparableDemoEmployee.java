package com.cg.day5;

import java.util.ArrayList;
import java.util.Collections;

public class ComparableDemoEmployee {

	public static void main(String[] args) {
		
		ArrayList<Empl> el =  new ArrayList<Empl>();
		el.add(new Empl(101,"Govind",20000));
		el.add(new Empl(102,"Karuna",45000));
		el.add(new Empl(103,"Kavin",25000));
		
		Collections.sort(el);
		
		
		for(Empl e : el)
		{
			
			System.out.println(e);
		}
		
		
	}
	
	
	
}


class Empl implements Comparable<Empl>{

	int eno;
	String name;
	double esal;
	

	
	
	
	public Empl(int eno, String name, double esal) {
		this.eno = eno;
		this.name = name;
		this.esal = esal;
	}





	@Override
	public int compareTo(Empl o) {
		// TODO Auto-generated method stub
		if(esal == o.esal)
			return 0;
		else if(esal > o.esal)
			return 1;
		else
			return -1;
			
	}


	@Override
	public String toString() {
		return "Empl [eno=" + eno + ", name=" + name + ", esal=" + esal + "]";
	}

}