package com.cg.day2;


public class CheckLastDigits {

	static boolean findDigitsEqual(int firstNumber, int secondNumber)
	{
	int digit1 = firstNumber%10;
	int digit2 = secondNumber%10;
	
	if(digit1 == 0 && digit1 == digit2)
	{
		return true;
	}
	else
		return false;

	}
}
