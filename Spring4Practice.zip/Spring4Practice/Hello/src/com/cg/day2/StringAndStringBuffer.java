package com.cg.day2;

public class StringAndStringBuffer {

	public static void main(String[] args) {
		
		String s = "Jessica Miller";
		
		StringBuffer sb =  new StringBuffer();
		sb.append(s.substring(8));
		sb.append(",");
		sb.append(s.substring(0,1));
		System.out.println(sb);
	}
	
}
