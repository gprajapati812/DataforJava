package com.cg.day2;

import java.util.Scanner;

public class UserMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter User ID : ");
		User.setUserId(sc.nextInt());
		
		System.out.println("Enter User Name : ");
		User.setUserName(sc.next());
		
		System.out.println(User.displayUserDetails());
	}
		
}
