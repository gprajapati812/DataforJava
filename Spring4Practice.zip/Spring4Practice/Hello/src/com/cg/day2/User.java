package com.cg.day2;

public class User {

	private static int userId;
	private static String userName;
	

	public static void setUserId(int userId) {
		User.userId = userId;
	}
	
	public static void setUserName(String userName) {
		User.userName = userName;
	}
	
	public static String displayUserDetails()
	{
		
		return ("User Id : "+userId+" \nUser Name : "+userName);
	}
	
}
