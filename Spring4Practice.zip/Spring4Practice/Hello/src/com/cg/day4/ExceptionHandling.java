package com.cg.day4;

public class ExceptionHandling {

	public static void main(String[] args) {
		/*
		 * 
		String s = null;
		System.out.println(s.length());
		
		*/ 
		
		/*
		
		Exception in thread "main" java.lang.NullPointerException
		at com.cg.day4.ExceptionHandling.main(ExceptionHandling.java:7)
		
		*/
		
		/*
		
		String s = "abc123";
		int a = Integer.parseInt(s);
		System.out.println(a);
		
		*/
//		Exception in thread "main" java.lang.NumberFormatException: For input string: "abc123"
		
		
		
//		int d = 10/0;
// Exception in thread "main" java.lang.ArithmeticException: / by zero		
		
		/*try{
			int a[] = new int[5];
			a[6] = 90;
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic Exception arrived");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array overflow");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Generic Exception");
		}
		
		finally{
			System.out.println("Always Execute");
			
		}*/
		ExceptionHandling.checkAge(16);
		
		
	}
	

	static void checkAge(int age)
	{
		if(age < 18)
		{
			
			throw new ArithmeticException("Invalid Age");
		}
		else
		{
			System.out.println("Valid Age");
		}
	}
	
}
