package com.cg.day4;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternMatching {

	public static void main(String[] args) {
		
	/*	
	 * 	String s = "capg";
		String pattern = "[a-z]{2,5}"; // mini length is 2 and max length is 5
		boolean b = Pattern.matches(pattern, s);
		System.out.println(b);
	
		String pno = "8286301908";
		String reg = "[789]{1}[0-9]{9}"; // phone number must be start with 7 8 9 
		boolean b1 = Pattern.matches(reg, pno);
		System.out.println(b1);
		
		String digitpat = "[0-9]*"; //Any number of digits only
		String dginput = "9856";
		boolean b2 = Pattern.matches(digitpat, dginput);
		System.out.println(b2);
		
		String regCap = "[A-Z]{1}[a-z]*";
		String name = "Capgemini";
		boolean b3 = Pattern.matches(regCap, name);
		System.out.println(b3);
		*/
		
		Pattern p = Pattern.compile("[0-9]{1}[a-zA-Z]{3,}");// input mini 3 max to n 
		Matcher m = p.matcher("1abAB");
		boolean b = m.matches();
		System.out.println(b);
		
	
		
	}
	
}
