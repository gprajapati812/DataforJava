package com.cg.day4;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayCollection {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter size of Array ");
		int n = sc.nextInt();
		/*int a[] = new int[n];
		System.out.println("Enter elements of array");
		for(int i=0;i<a.length;i++)
			a[i] = sc.nextInt();
		
		
		
		
		Arrays.sort(a);
		System.out.println("Sorted Array is");
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
		int min = a[0];
		int max = a[a.length - 1];
		
		System.out.println("Addition of Largest and smallest number is "+(min+max));
		System.out.println("Middle element is "+a[a.length/2]);
		*/
		
		String s[] = new String[n];
		System.out.println("Enter elements of array");
		for(int i=0;i<n;i++)
			s[i] = sc.next();
		Arrays.sort(s);
		
		System.out.println("Sorted Array is");
		/*for(int i=0;i<n;i++)
			System.out.println(s[i]);*/
		
		for(String str:s) // using for each loop 1.5 features
		{
			System.out.println(str);
		}
		
		
		
		
		// 
		
		
		
	}
	
}
