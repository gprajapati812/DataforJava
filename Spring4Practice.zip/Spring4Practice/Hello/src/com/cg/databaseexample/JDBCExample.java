package com.cg.databaseexample;

import java.sql.*;
import java.util.Scanner;

public class JDBCExample {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		JdbcData jd = new JdbcData();
		jd.application();
		
		//jd.insertIntoDatabase();
		
		//jd.application();
		
	}
	
}


class JdbcData
{
	void application() throws ClassNotFoundException, SQLException{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg304","training304");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * From empl");
		while(rs.next())
		{
			System.out.println("Emp Id : "+rs.getInt(1)+"\n"+"Emp Name :"+rs.getString(2)+"\n\n");
			
		}
		con.close();
		
		
	}

	public void insertIntoDatabase() throws ClassNotFoundException, SQLException {
		
		Scanner sc = new Scanner(System.in);
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg304","training304");
		Statement st = con.createStatement();
		
		PreparedStatement pst = con.prepareStatement("Insert into Empl values(?,?)");
		System.out.println("Enter Emp Id: ");
		
		pst.setInt(1,sc.nextInt());
		
		System.out.println("Enter Emp Name: ");
		
		pst.setString(2,sc.next());
		
		int r = pst.executeUpdate();
		System.out.println(r+" row inserted");
		
		con.close();
	}

}

