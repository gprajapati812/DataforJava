package com.cg.day3;

import java.awt.geom.Rectangle2D;



abstract class Shape
{
	abstract void display();
	void draw()
	{
		System.out.println("Draw Method in Abstract Class");
	}
}


class Rectangle extends Shape
{
	void display()
	{
		System.out.println("This is Display Method in Rectangle Class");
		
	}
}

public class AbstractOperations {

	public static void main(String[] args) {
		
		// How to create Object 
		Shape s = new Rectangle(); // both way is possible to create object 
		
		//Rectangle r  =  new Rectangle(); // reference of parent class and object must be created by base class
		
		s.draw();	
		s.display();
			
	}
	
	
}
