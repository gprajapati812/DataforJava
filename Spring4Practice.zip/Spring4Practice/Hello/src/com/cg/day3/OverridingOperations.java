package com.cg.day3;

public class OverridingOperations {

	public static void main(String[] args) {
		College c =  new College();
		
		c.showDetails();
		
		Student s =  new Student();
		s.showDetails();
		
	}
	
}


class College
{
	String clgName = "Kj Somaiya";
	void showDetails()
	{
		System.out.println("In College Class \n College Name is "+clgName);
		
	}
}

class Student extends College
{
	String studName="Govind";
	void showDetails()
	{
		
		System.out.println("In Student Class \n College Name is "+super.clgName);
		System.out.println("Name is "+studName);
	}
}