package com.cg.eis.pl;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class UserInteraction {

	public static void main(String[] args) {
		
		
		UserDetails ud = new UserDetails();
		ud.acceptEmployeeDetails();
		
	}
	
}


class UserDetails
{
	Scanner sc = new Scanner(System.in);
	HashMap<Integer,Employee> empMap = new HashMap<Integer,Employee>();
	
	void acceptEmployeeDetails()
	{
		
	/*	System.out.println("Enter number of Employee to Enter");
		int n = sc.nextInt();
	
		for(int i = 0;i<n;i++)
		{
		sc.nextLine();
		System.out.println("Enter Employee Details :");
		System.out.println("Enter Employee Name ");
		String eName = sc.nextLine();
		System.out.println("Enter Employee Designation ");
		String eDesign = sc.nextLine();
		System.out.println("Enter Employee Salary");
		double eSalary = sc.nextDouble();
		Employee emp =  new Employee(eName,eDesign,eSalary);
		empMap.put((i+1),emp);
		
		}
		
		*/
		
		empMap.put(1,new Employee("Govind","Programmer",25000));
		empMap.put(2,new Employee("Shubham","Manager",45000));
		empMap.put(3,new Employee("Rohit","Clerk",4500));
		
	
		for(Map.Entry<Integer, Employee> out : empMap.entrySet())
		{
			
			Integer key = out.getKey();
			Employee value = out.getValue();
			
			System.out.println(key+ " = > "+value);
		}
	}
	
}
