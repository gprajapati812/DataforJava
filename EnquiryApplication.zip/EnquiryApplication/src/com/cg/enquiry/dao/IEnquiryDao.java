package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.dto.EnquiryDetails;


public interface IEnquiryDao {

	public int addEnquiryDetails(EnquiryDetails p);
	public int checkDetailExist(int enquiryid);
	public EnquiryDetails retrieveDetails(int enquiryid) throws IOException, SQLException;
	
}
