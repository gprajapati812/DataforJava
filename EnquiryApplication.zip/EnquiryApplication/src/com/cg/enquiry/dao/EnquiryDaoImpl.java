package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import com.cg.enquiry.dbutil.EnquiryDBUtil;
import com.cg.enquiry.dto.EnquiryDetails;





public class EnquiryDaoImpl implements IEnquiryDao{

	public int addEnquiryDetails(EnquiryDetails p) {
		int rows=0;
		
		try {
			
			Connection conn = EnquiryDBUtil.getConnection();
			String insertQuery="insert into enquiry values(enquiry_seq_id.nextval,?,?,?,?,?)";
			PreparedStatement ps=conn.prepareStatement(insertQuery);
			ps.setString(1, p.getFname());	
			ps.setString(2, p.getLname());
			ps.setLong(3, p.getPhone());
			ps.setString(4, p.getDomain());
			ps.setString(5, p.getLoc());
			
			rows = ps.executeUpdate();
		
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rows;
		
	}
	public int checkDetailExist(int enquiryid)
	{
		Connection conn;
		int status = 0;
		try {
			conn = EnquiryDBUtil.getConnection();
			
			String str = "select * from enquiry where enquiryid=?";
			PreparedStatement ps = conn.prepareStatement(str);
			//int mi = Integer.parseInt(mobid);
			//System.out.println(mi);
			ps.setInt(1, enquiryid);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				status = rs.getInt(1);
			}

			System.out.println(status);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
		
	}

	public EnquiryDetails retrieveDetails(int enquiryid) throws IOException, SQLException {
	
		
			System.out.println(enquiryid);
			Connection conn;
			
				conn = EnquiryDBUtil.getConnection();
				String str = "select * from enquiry where enquiryid=?";
				
				PreparedStatement ps = conn.prepareStatement(str);
				ps.setInt(1, enquiryid);
				ResultSet rs = ps.executeQuery();
				EnquiryDetails rd = new EnquiryDetails();
				while(rs.next())
				{
					rd.setId(rs.getInt(1)); 
					rd.setFname(rs.getString(2)); 
					rd.setLname(rs.getString(3));
					rd.setPhone(rs.getLong(4)); 
					rd.setDomain(rs.getString(5)); 
					rd.setLoc(rs.getString(6));
				
					
				}
				
		
			
		return rd;
	

}
}
