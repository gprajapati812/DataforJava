package com.cg.enquiry.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.dao.IEnquiryDao;
import com.cg.enquiry.dto.EnquiryDetails;



public class EnquiryServiceImpl implements IEnquiryService{

	IEnquiryDao dao = new EnquiryDaoImpl();
	public int addEnquiryDetails(EnquiryDetails p) {
		
		IEnquiryDao dao = new EnquiryDaoImpl();
		return dao.addEnquiryDetails(p);
	}

	
	public int checkDetailExist(int enquiryid)
	{
		int result= dao.checkDetailExist(enquiryid);
		return result;
		
	}
	
	public EnquiryDetails retrieveDetails(int enquiryid) throws IOException, SQLException {
		
		EnquiryDetails ed = new EnquiryDetails();
		ed = dao.retrieveDetails(enquiryid);
		
		return ed;
	}

	
}
