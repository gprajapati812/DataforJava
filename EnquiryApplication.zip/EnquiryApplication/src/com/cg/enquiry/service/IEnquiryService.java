package com.cg.enquiry.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.dto.EnquiryDetails;




public interface IEnquiryService {

	public int addEnquiryDetails(EnquiryDetails p);
	public int checkDetailExist(int enquiryid);
	public EnquiryDetails retrieveDetails(int enquiryid) throws IOException, SQLException;
}
