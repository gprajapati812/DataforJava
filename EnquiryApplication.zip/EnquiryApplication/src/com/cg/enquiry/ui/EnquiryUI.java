package com.cg.enquiry.ui;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.enquiry.dbutil.EnquiryDBUtil;
import com.cg.enquiry.dto.EnquiryDetails;


import com.cg.enquiry.service.EnquiryServiceImpl;
import com.cg.enquiry.service.IEnquiryService;



public class EnquiryUI {

	static Scanner sc = new Scanner(System.in);
	static EnquiryDetails details=null;
	
	static IEnquiryService service= new EnquiryServiceImpl();
	static EnquiryUI ui= new EnquiryUI();
	
	public static void main(String[] args) throws IOException, SQLException {
		
		System.out.println("Enquiry Application");
		System.out.println("_______________________");
		while(true)
		{
			System.out.println("1.Enter Enquiry Details");
			System.out.println("2.Enter your Enquiry id");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 1 : addEnquiryDetails();
						break;
			case 2 : checkDetailExist();
						break;
			case 3 : System.exit(0);
			}
		}
		
							}
							
	private static void addEnquiryDetails()
	{
		System.out.println("Enter First Name");
		String fname = sc.next();
		
			System.out.println("Enter Last Name");
			String lname = sc.next();
		
				System.out.println("Enter Phone number");
				long phone = sc.nextLong();
				
		
					System.out.println("Enter Domain");
					String domain = sc.next();
								
					System.out.println("Enter Preffered location");
					String loc = sc.next();
		
								details = new EnquiryDetails(fname,lname,phone,domain,loc); 
								
								service = new EnquiryServiceImpl();
		
								int no_of_rows = service.addEnquiryDetails(details);
								System.out.println(no_of_rows+" rows inserted");
									if(no_of_rows==1)
									{
										System.out.println("Value added in database");
									}
									else
									{
										System.out.println("value not added");
									}
		
	}
	
	private static void checkDetailExist() throws IOException, SQLException
	{
		System.out.println("Enter the enquiry no: ");
		 int enquiryid = sc.nextInt();
		int status = service.checkDetailExist(enquiryid);
		if(status == 0)
		{
			System.out.println("not found");
		}
			else
			{
				System.out.println("found!");
				ui.retrieveDetails(enquiryid);
			}	
			
	}
	private void retrieveDetails(int enquiryid) throws IOException, SQLException
	{
		System.out.println("i will access array here");
		EnquiryDetails ed = new EnquiryDetails();
		ed = service.retrieveDetails(enquiryid);
		System.out.println(ed);
	}
	
}
