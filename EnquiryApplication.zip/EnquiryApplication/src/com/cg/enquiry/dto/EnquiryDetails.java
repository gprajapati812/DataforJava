package com.cg.enquiry.dto;

public class EnquiryDetails {

	public int getEnquiryid() {
		return enquiryid;
	}
	public void setEnquiryid(int enquiryid) {
		this.enquiryid = enquiryid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "\t" + fname + ", \t" + lname
				+ ", \t" + phone + ", \t" + domain + ",\t" + loc
				+ "]";
	}
	private int id;
	private String fname;
	private String lname;
	private Long phone;
	private String domain;
	private String loc;
	private int enquiryid;
	
	
	//Parameterized constructor
	public EnquiryDetails( String fname, String lname, Long phone,
			String domain, String loc) {
		super();
		//this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.phone = phone;
		this.domain = domain;
		this.loc = loc;
	}
	//Default Constructor
	public EnquiryDetails()
	{
		
	}
	

	//Getter Setters
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
	
	
	
}
