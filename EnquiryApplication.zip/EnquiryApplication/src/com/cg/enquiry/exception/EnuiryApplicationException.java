package com.cg.enquiry.exception;

public class EnuiryApplicationException {

}
